document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'es',
        events: [
            {
                title: 'Evento de Prueba',
                start: '2023-10-01'
            },
            {
                title: 'Otro Evento',
                start: '2023-10-07',
                end: '2023-10-10'
            }
        ]
    });

    calendar.render();
}); 